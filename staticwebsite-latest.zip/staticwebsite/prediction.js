document.getElementById('predictionForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent form submission
    
    // Get form values
    var name = document.getElementById('name').value;
    var age = document.getElementById('age').value;
    var sex = document.getElementById('sex').value;
    var symptoms = document.getElementById('symptoms').value;
    
    // Do something with the form data, such as sending it to a server for processing
    
    // For now, let's just log the data to the console
    console.log('Name: ' + name);
    console.log('Age: ' + age);
    console.log('Sex: ' + sex);
    console.log('Symptoms: ' + symptoms);
});
